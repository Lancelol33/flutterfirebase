import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show kIsWeb;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    throw UnsupportedError('Only web is supported on Zapp.run.');
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey:            'AIzaSyBhtn0QbLuXDcShUHr-jC-9wSr78CiisKY',
    appId:             '1:979761111549:web:ef47ba3cf480faa92ef994',
    messagingSenderId: '979761111549',
    projectId:         'todoappsample1',
    authDomain:        'todoappsample1.firebaseapp.com',
    storageBucket:     'todoappsample1.firebasestorage.app',
  );
}